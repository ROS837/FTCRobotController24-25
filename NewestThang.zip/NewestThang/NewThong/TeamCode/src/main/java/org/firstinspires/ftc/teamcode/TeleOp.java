package org.firstinspires.ftc.teamcode;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.hardware.DcMotorSimple;

@com.qualcomm.robotcore.eventloop.opmode.TeleOp(name = "TeleOp", group = "teleOp")
public class TeleOp extends LinearOpMode {
    Robot robot;
    @Override
    public void runOpMode() throws InterruptedException {
        robot = new Robot(this);
        waitForStart();
        while(opModeIsActive()){
            setDirections();

            double mult = 1;
            if(gamepad1.left_trigger > 0) {
                mult = .8 - (.6 * gamepad1.left_trigger);
            } else {
                mult = .8;
            }

            boolean lStickXBool = gamepad1.left_stick_x > .15 || gamepad1.left_stick_x < -.15;
            boolean lStickYBool = gamepad1.left_stick_y > .15 || gamepad1.left_stick_y < -.15;
            if(lStickXBool || lStickYBool) {
                drive360(gamepad1.left_stick_x, gamepad1.left_stick_y, mult);
            } else {
                drive360(0, 0, 0);
            }

            if(gamepad1.y) {
                go("forward");
            } else if(gamepad1.a) {
                go("reverse");
            } else if(gamepad1.x) {
                go("left");
            } else if(gamepad1.b) {
                go("right");
            } else {
                drive360(0,0,0);
            }
        }
    }

    //HELPER FUNCTIONS
    private void setDirections() {
        robot.lF.setDirection(DcMotorSimple.Direction.REVERSE);
        robot.lB.setDirection(DcMotorSimple.Direction.REVERSE);
        robot.rF.setDirection(DcMotorSimple.Direction.FORWARD);
        robot.rB.setDirection(DcMotorSimple.Direction.FORWARD);
    }

    private void drive360(double x,  double y, double pwr) {
        robot.lF.setPower((- y + x) * pwr);
        robot.lB.setPower((- y - x) * pwr);
        robot.rF.setPower((- y - x) * pwr);
        robot.rB.setPower((- y + x) * pwr);
    }

    private void go(String direction) {
        if(direction == "forward") {
            robot.lF.setPower(.8);
            robot.lB.setPower(.8);
            robot.rF.setPower(.8);
            robot.rB.setPower(.8);
        }
        if(direction == "reverse") {
            robot.lF.setPower(-.8);
            robot.lB.setPower(-.8);
            robot.rF.setPower(-.8);
            robot.rB.setPower(-.8);
        }
        if(direction == "left") {
            robot.lF.setPower(.8);
            robot.lB.setPower(-.8);
            robot.rF.setPower(-.8);
            robot.rB.setPower(.8);
        }
        if(direction == "right") {
            robot.lF.setPower(-.8);
            robot.lB.setPower(.8);
            robot.rF.setPower(.8);
            robot.rB.setPower(-.8);
        }
    }
}