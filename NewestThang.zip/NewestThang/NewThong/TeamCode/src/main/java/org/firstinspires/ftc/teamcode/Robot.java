// Mark II
// Devashish Das 2023-2024
// Rohin Sharma 2023-2024

package org.firstinspires.ftc.teamcode;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.Servo;

public class Robot {
    LinearOpMode ln;

    DcMotor lF;
    DcMotor lB;
    DcMotor rB;
    DcMotor rF;

    public Robot(LinearOpMode ln){
       lF = ln.hardwareMap.dcMotor.get("lF");
       lB = ln.hardwareMap.dcMotor.get("lB");
       rB = ln.hardwareMap.dcMotor.get("rB");
       rF = ln.hardwareMap.dcMotor.get("rF");
    }
}