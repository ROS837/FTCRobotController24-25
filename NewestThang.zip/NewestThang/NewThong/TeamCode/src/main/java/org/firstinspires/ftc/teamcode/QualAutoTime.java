package org.firstinspires.ftc.teamcode;

import com.acmerobotics.dashboard.FtcDashboard;
import com.acmerobotics.dashboard.config.Config;
import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.hardware.Gamepad;
import com.qualcomm.robotcore.util.ElapsedTime;

import org.firstinspires.ftc.robotcore.external.hardware.camera.WebcamName;
import org.openftc.easyopencv.OpenCvCamera;
import org.openftc.easyopencv.OpenCvCameraFactory;
import org.openftc.easyopencv.OpenCvCameraRotation;
import org.openftc.easyopencv.OpenCvWebcam;

@Config
@Autonomous(name = "Time Sauce", group = "Autonomous")
public class QualAutoTime extends LinearOpMode {
    /*
     * If program has a build folder error try clearing the build
     */
    public static int AWAY_FORWARD = 820;
    public static int TOWARD_FORWARD = 1310;
    public static int MIDDLE_FORWARD_POSITION = 1245;
    public static int LEFT_TOWARD_STRAFE = -520;
    public static int RIGHT_TOWARD_STRAFE = -600;
    public static double WHEEL_POWER = 0.5;
    public static int RIGHT_OFFSET_STRAFE = 640;
    public static int LEFT_OFFSET_STRAFE = 520;
    public static int MIDDLE_OFFSET_STRAFE = 200;
    public static int FAR_DISTANCE_TO_BACKDROP = 3000;
    public static int CLOSE_DISTANCE_TO_BACKDROP = 850;
    public static int MIDDLE_BACK_UP = 1200;
    public static int BACKUP = 650;
    public static int SMALL_BACKUP = 200;
    public static int SORTA_EXTRA_BACKUP = 750;
    public static int EXTRA_BACKUP = 1200;
    public static int EXTRA_EXTRA_BACKUP = 1400;
    public static int SAME_DIRECTION_PARK_DISTANCE = 1000;
    public static int DIFFERENT_DIRECTION_PARK_DISTANCE = 1700;
    public static int MIDDLE_PARK_DISTANCE = 1400;

    static final double block = 575;
    static final double COUNTS_PER_MOTOR_REV = 1440 ;    // eg: TETRIX Motor Encoder
    static final double DRIVE_GEAR_REDUCTION = 2.0 ;     // This is < 1.0 if geared UP
    static final double WHEEL_DIAMETER_INCHES = 4.0 ;     // For figuring circumference
    static final double COUNTS_PER_INCH = (COUNTS_PER_MOTOR_REV * DRIVE_GEAR_REDUCTION)/(WHEEL_DIAMETER_INCHES * 3.1415);
    private Boolean redAlliance = null;
    private Boolean startLeft = null;
    private Boolean parkLeft = null; //PARK LEFT IS NOT NECESSARY, THE COLOR IS USED TO DENOTE WHERE TO PARK
    OpenCvWebcam camera;

    Robot robot;
    private boolean startedStreaming;

    private ElapsedTime runtime = new ElapsedTime();

    @Override
    public void runOpMode() throws InterruptedException {
        Gamepad currentGamepad = new Gamepad();

        while (true) {
            currentGamepad.copy(gamepad1);

            if (redAlliance == null) {
                telemetry.addData("Alliance", "X = blue, B = red");
                telemetry.update();
                if (currentGamepad.x) {
                    redAlliance = false;
                }
                if (currentGamepad.b) {
                    redAlliance = true;
                }
            }
            if (startLeft == null) {
                telemetry.addData("Start", "X = left, B = right");
                telemetry.update();
                if (currentGamepad.x) {
                    startLeft = true;
                }
                if (currentGamepad.b) {
                    startLeft = false;
                }
            } else {
                break;
            }
        }

        robot = new Robot(this);

        int cameraMonitorViewId = hardwareMap.appContext.getResources().getIdentifier("cameraMonitorViewId", "id", hardwareMap.appContext.getPackageName());
        camera = OpenCvCameraFactory.getInstance().createWebcam(hardwareMap.get(WebcamName.class, "Webcam 1"), cameraMonitorViewId);
        OpenCVDetection detector = new OpenCVDetection(parkLeft, redAlliance, startLeft, telemetry);
        camera.setPipeline(detector);
        camera.setMillisecondsPermissionTimeout(5000); // Timeout for obtaining permission is configurable. Set before opening.
        telemetry.addLine("opening camera");
        /*
         *   Below is an example of a lambda expression which is in simply an anonymous function.
         *   Since we are only executing one statement we are able to remove the curly braces and semicolon
         *   making it look much cleaner.
         *   Note that this is a feature strictly for SDK 8+, if Java 7 is being used use this code instead.
         *   To change preferences press command and ; to open up preference window.
         *
         *   * Lambda Expression *
         *   camera.openCameraDeviceAsync(() -> camera.startStreaming(320,240, OpenCvCameraRotation.UPRIGHT));
         */
        camera.openCameraDeviceAsync(new OpenCvCamera.AsyncCameraOpenListener() {
            @Override
            public void onOpened() {
                /*
                 * Tell the webcam to start streaming images to us! Note that you must make sure
                 * the resolution you specify is supported by the camera. If it is not, an exception
                 * will be thrown.
                 *
                 * Keep in mind that the SDK's UVC driver (what OpenCvWebcam uses under the hood) only
                 * supports streaming from the webcam in the uncompressed YUV image format. This means
                 * that the maximum resolution you can stream at and still get up to 30FPS is 480p (640x480).
                 * Streaming at e.g. 720p will limit you to up to 10FPS and so on and so forth.
                 *
                 * Also, we specify the rotation that the webcam is used in. This is so that the image
                 * from the camera sensor can be rotated such that it is always displayed with the image upright.
                 * For a front facing camera, rotation is defined assuming the user is looking at the screen.
                 * For a rear facing camera or a webcam, rotation is defined assuming the camera is facing
                 * away from the user.
                 */
                camera.startStreaming(800, 448, OpenCvCameraRotation.UPRIGHT);
                startedStreaming = true;
                telemetry.addLine("started camera streaming");
            }

            @Override
            public void onError(int errorCode) {
                /*
                 * This will be called if the camera could not be opened
                 */
                telemetry.addLine("Rats!" + errorCode);
            }


        });

        FtcDashboard.getInstance().startCameraStream(camera, 0);

        while (opModeIsActive() && !startedStreaming) {
            telemetry.addLine("waiting for camera streaming to start");
            sleep(50);
        }

        OpenCVDetection.Location location = null;

        while (opModeIsActive() && location == null) {
            telemetry.addLine("waiting for location detection");
            sleep(50);
            location = detector.getLocation();
        }

        waitForStart();

        location = detector.getLocation(); //if (location == OpenCVDetection.Location.Left)

        camera.stopStreaming();

        camera.closeCameraDevice();

        //waitForStart();

        while (opModeIsActive()) {
            /*telemetry.addData("Motor movement: ", robot.lF.isBusy() + " | " + robot.rF.isBusy() + " | " + robot.lB.isBusy() + " | " + robot.rB.isBusy());
            telemetry.update();
            if(location  == OpenCVDetection.Location.Left){
                telemetry.addLine("Left");
                if(redAlliance){
                    telemetry.addLine("Left");
                    if(startLeft){
                        initForward();
                        robot.setMotorPowers(1);
                        sleep(250); //could be too little
                        initLeftStrafe();
                        robot.setMotorPowers(1);
                        sleep(575/2);
                        initRightStrafe();
                        robot.setMotorPowers(1);
                        sleep(575/2);
                        initForward();
                        robot.setMotorPowers(1);
                        sleep(575-250);
                        robot.setMotorPowers(1);
                        sleep(575);
                        initRightStrafe();
                        robot.setMotorPowers(1);
                        sleep(575*3);
                        initRightTurn();
                        robot.setMotorPowers(1);
                        sleep(1000); //TEST TURN
                        initRightStrafe();
                        robot.setMotorPowers(1);
                        sleep(575/2 + 20); // CHANGE
                        initForward();
                        robot.setMotorPowers(1);
                        sleep(575/2);
                        robot.pixelServo.setPosition(1);
                        initBackward();
                        robot.setMotorPowers(1);
                        sleep(575);
                        initRightStrafe();
                        robot.setMotorPowers(1);
                        sleep(575 + (575/2));
                        initForward();
                        robot.setMotorPowers(1);
                        sleep(575);
                    }
                    else{
                        initForward();
                        robot.setMotorPowers(1);
                        sleep(250); //could be too little
                        initLeftStrafe();
                        robot.setMotorPowers(1);
                        sleep(575/2);
                        initRightStrafe();
                        robot.setMotorPowers(1);
                        sleep(575/2);
                        initBackward();
                        robot.setMotorPowers(1);
                        sleep(250 + 575); //could be too little
                        initRightTurn();
                        robot.setMotorPowers(1);
                        sleep(1000); //TEST TURN
                        initForward();
                        robot.setMotorPowers(1);
                        sleep(575+575+(575/2));
                        initLeftStrafe();
                        robot.setMotorPowers(1);
                        sleep(575 + (575/2) + 20);
                        robot.pixelServo.setPosition(1);
                        initRightStrafe();
                        robot.setMotorPowers(1);
                        sleep(575 + (575/2) + 20);
                        initForward();
                        robot.setMotorPowers(1);
                        sleep(575/2);
                    }
                }
                else{
                    if(startLeft){
                        initForward();
                        robot.setMotorPowers(1);
                        sleep(250); //could be too little
                        initLeftStrafe();
                        robot.setMotorPowers(1);
                        sleep(575/2);
                        initRightStrafe();
                        robot.setMotorPowers(1);
                        sleep(575/2);
                        initBackward();
                        robot.setMotorPowers(1);
                        sleep(250 + 575); //could be too little
                        initLeftTurn();
                        robot.setMotorPowers(1);
                        sleep(1000); //TEST TURN
                        initForward();
                        robot.setMotorPowers(1);
                        sleep(575+575+(575/2));
                        initRightStrafe();
                        robot.setMotorPowers(1);
                        sleep(575/2);
                        robot.pixelServo.setPosition(1);
                        initLeftStrafe();
                        robot.setMotorPowers(1);
                        sleep(575/2);
                        initForward();
                        robot.setMotorPowers(1);
                        sleep(575/2);
                    }
                    else{
                        initForward();
                        robot.setMotorPowers(1);
                        sleep(250); //could be too little
                        initLeftStrafe();
                        robot.setMotorPowers(1);
                        sleep(575/2);
                        initRightStrafe();
                        robot.setMotorPowers(1);
                        sleep(575/2);
                        initForward();
                        robot.setMotorPowers(1);
                        sleep(575-250);
                        robot.setMotorPowers(1);
                        sleep(575);
                        initRightStrafe();
                        robot.setMotorPowers(1);
                        sleep(575*3);
                        initRightTurn();
                        robot.setMotorPowers(1);
                        sleep(1000); //TEST TURN
                        initRightStrafe();
                        robot.setMotorPowers(1);
                        sleep(575/2 + 20); // CHANGE
                        initForward();
                        robot.setMotorPowers(1);
                        sleep(575/2);
                        robot.pixelServo.setPosition(1);
                        initBackward();
                        robot.setMotorPowers(1);
                        sleep(575);
                        initRightStrafe();
                        robot.setMotorPowers(1);
                        sleep(575 + (575/2));
                        initForward();
                        robot.setMotorPowers(1);
                        sleep(575);
                    }
                }
            }
            if(location  == OpenCVDetection.Location.Middle){
                if(redAlliance){
                    if(startLeft){
                        initForward();
                        robot.setMotorPowers(1);
                        sleep(250); //could be too little
                        initLeftStrafe();
                        robot.setMotorPowers(1);
                        sleep(575/2);
                        initRightStrafe();
                        robot.setMotorPowers(1);
                        sleep(575/2);
                        initForward();
                        robot.setMotorPowers(1);
                        sleep(575-250);
                        robot.setMotorPowers(1);
                        sleep(575);
                        initRightStrafe();
                        robot.setMotorPowers(1);
                        sleep(575*3);
                        initRightTurn();
                        robot.setMotorPowers(1);
                        sleep(1000); //TEST TURN
                        initRightStrafe();
                        robot.setMotorPowers(1);
                        sleep(575/2 + 20); // CHANGE
                        initForward();
                        robot.setMotorPowers(1);
                        sleep(575/2);
                        robot.pixelServo.setPosition(1);
                        initBackward();
                        robot.setMotorPowers(1);
                        sleep(575);
                        initRightStrafe();
                        robot.setMotorPowers(1);
                        sleep(575 + (575/2));
                        initForward();
                        robot.setMotorPowers(1);
                        sleep(575);
                    }
                    else{
                        initForward();
                        robot.setMotorPowers(1);
                        sleep(250); //could be too little
                        initLeftStrafe();
                        robot.setMotorPowers(1);
                        sleep(575/2);
                        initRightStrafe();
                        robot.setMotorPowers(1);
                        sleep(575/2);
                        initBackward();
                        robot.setMotorPowers(1);
                        sleep(250 + 575); //could be too little
                        initRightTurn();
                        robot.setMotorPowers(1);
                        sleep(1000); //TEST TURN
                        initForward();
                        robot.setMotorPowers(1);
                        sleep(575+575+(575/2));
                        initLeftStrafe();
                        robot.setMotorPowers(1);
                        sleep(575 + (575/2) + 20);
                        robot.pixelServo.setPosition(1);
                        initRightStrafe();
                        robot.setMotorPowers(1);
                        sleep(575 + (575/2) + 20);
                        initForward();
                        robot.setMotorPowers(1);
                        sleep(575/2);
                    }
                }
                else{
                    if(startLeft){
                        initForward();
                        robot.setMotorPowers(1);
                        sleep(250); //could be too little
                        initLeftStrafe();
                        robot.setMotorPowers(1);
                        sleep(575/2);
                        initRightStrafe();
                        robot.setMotorPowers(1);
                        sleep(575/2);
                        initBackward();
                        robot.setMotorPowers(1);
                        sleep(250 + 575); //could be too little
                        initLeftTurn();
                        robot.setMotorPowers(1);
                        sleep(1000); //TEST TURN
                        initForward();
                        robot.setMotorPowers(1);
                        sleep(575+575+(575/2));
                        initRightStrafe();
                        robot.setMotorPowers(1);
                        sleep(575/2);
                        robot.pixelServo.setPosition(1);
                        initLeftStrafe();
                        robot.setMotorPowers(1);
                        sleep(575/2);
                        initForward();
                        robot.setMotorPowers(1);
                        sleep(575/2);
                    }
                    else{
                        initForward();
                        robot.setMotorPowers(1);
                        sleep(250); //could be too little
                        initLeftStrafe();
                        robot.setMotorPowers(1);
                        sleep(575/2);
                        initRightStrafe();
                        robot.setMotorPowers(1);
                        sleep(575/2);
                        initForward();
                        robot.setMotorPowers(1);
                        sleep(575-250);
                        robot.setMotorPowers(1);
                        sleep(575);
                        initRightStrafe();
                        robot.setMotorPowers(1);
                        sleep(575*3);
                        initRightTurn();
                        robot.setMotorPowers(1);
                        sleep(1000); //TEST TURN
                        initRightStrafe();
                        robot.setMotorPowers(1);
                        sleep(575/2 + 20); // CHANGE
                        initForward();
                        robot.setMotorPowers(1);
                        sleep(575/2);
                        robot.pixelServo.setPosition(1);
                        initBackward();
                        robot.setMotorPowers(1);
                        sleep(575);
                        initRightStrafe();
                        robot.setMotorPowers(1);
                        sleep(575 + (575/2));
                        initForward();
                        robot.setMotorPowers(1);
                        sleep(575);
                    }
                }
            }

            if(location  == OpenCVDetection.Location.Right){
                if(redAlliance){
                    if(startLeft){
                        initForward();
                        robot.setMotorPowers(1);
                        sleep(250); //could be too little
                        initRightStrafe();
                        robot.setMotorPowers(1);
                        sleep(575/2);
                        initRightStrafe();
                        robot.setMotorPowers(1);
                        sleep(575/2);
                        initForward();
                        robot.setMotorPowers(1);
                        sleep(575-250);
                        robot.setMotorPowers(1);
                        sleep(575);
                        initRightStrafe();
                        robot.setMotorPowers(1);
                        sleep(575*3);
                        initRightTurn();
                        robot.setMotorPowers(1);
                        sleep(1000); //TEST TURN
                        initRightStrafe();
                        robot.setMotorPowers(1);
                        sleep(575/2 + 20); // CHANGE
                        initForward();
                        robot.setMotorPowers(1);
                        sleep(575/2);
                        robot.pixelServo.setPosition(1);
                        initBackward();
                        robot.setMotorPowers(1);
                        sleep(575);
                        initRightStrafe();
                        robot.setMotorPowers(1);
                        sleep(575 + (575/2));
                        initForward();
                        robot.setMotorPowers(1);
                        sleep(575);
                    }
                    else{
                        initForward();
                        robot.setMotorPowers(1);
                        sleep(250); //could be too little
                        initLeftStrafe();
                        robot.setMotorPowers(1);
                        sleep(575/2);
                        initRightStrafe();
                        robot.setMotorPowers(1);
                        sleep(575/2);
                        initBackward();
                        robot.setMotorPowers(1);
                        sleep(250 + 575); //could be too little
                        initRightTurn();
                        robot.setMotorPowers(1);
                        sleep(1000); //TEST TURN
                        initForward();
                        robot.setMotorPowers(1);
                        sleep(575+575+(575/2));
                        initLeftStrafe();
                        robot.setMotorPowers(1);
                        sleep(575 + (575/2) + 20);
                        robot.pixelServo.setPosition(1);
                        initRightStrafe();
                        robot.setMotorPowers(1);
                        sleep(575 + (575/2) + 20);
                        initForward();
                        robot.setMotorPowers(1);
                        sleep(575/2);
                    }
                }
                else{
                    if(startLeft){
                        initForward();
                        robot.setMotorPowers(1);
                        sleep(250); //could be too little
                        initLeftStrafe();
                        robot.setMotorPowers(1);
                        sleep(575/2);
                        initRightStrafe();
                        robot.setMotorPowers(1);
                        sleep(575/2);
                        initBackward();
                        robot.setMotorPowers(1);
                        sleep(250 + 575); //could be too little
                        initLeftTurn();
                        robot.setMotorPowers(1);
                        sleep(1000); //TEST TURN
                        initForward();
                        robot.setMotorPowers(1);
                        sleep(575+575+(575/2));
                        initRightStrafe();
                        robot.setMotorPowers(1);
                        sleep(575/2);
                        robot.pixelServo.setPosition(1);
                        initLeftStrafe();
                        robot.setMotorPowers(1);
                        sleep(575/2);
                        initForward();
                        robot.setMotorPowers(1);
                        sleep(575/2);
                    }
                    else{
                        initForward();
                        robot.setMotorPowers(1);
                        sleep(250); //could be too little
                        initLeftStrafe();
                        robot.setMotorPowers(1);
                        sleep(575/2);
                        initRightStrafe();
                        robot.setMotorPowers(1);
                        sleep(575/2);
                        initForward();
                        robot.setMotorPowers(1);
                        sleep(575-250);
                        robot.setMotorPowers(1);
                        sleep(575);
                        initRightStrafe();
                        robot.setMotorPowers(1);
                        sleep(575*3);
                        initRightTurn();
                        robot.setMotorPowers(1);
                        sleep(1000); //TEST TURN
                        initRightStrafe();
                        robot.setMotorPowers(1);
                        sleep(575/2 + 20); // CHANGE
                        initForward();
                        robot.setMotorPowers(1);
                        sleep(575/2);
                        robot.pixelServo.setPosition(1);
                        initBackward();
                        robot.setMotorPowers(1);
                        sleep(575);
                        initRightStrafe();
                        robot.setMotorPowers(1);
                        sleep(575 + (575/2));
                        initForward();
                        robot.setMotorPowers(1);
                        sleep(575);
                    }
                }
            }


        }
    }

    public void encoderDrive(double speed, double lF, double rF, double lB, double rB) {
        int newLFTarget;
        int newRFTarget;
        int newLBTarget;
        int newRBTarget;

        // Ensure that the opmode is still active
        if (opModeIsActive()) {

            // Determine new target position, and pass to motor controller
            newLFTarget = robot.lF.getCurrentPosition() + (int)(lF * COUNTS_PER_INCH);
            //newRFTarget = robot.rF.getCurrentPosition() + (int)(rF * COUNTS_PER_INCH);
            //newLBTarget = robot.lB.getCurrentPosition() + (int)(lB * COUNTS_PER_INCH);
            newRBTarget = robot.rB.getCurrentPosition() + (int)(rB * COUNTS_PER_INCH);

            robot.lF.setTargetPosition(newLFTarget);
            //robot.rF.setTargetPosition(-1);
            //robot.lB.setTargetPosition(-3);
            robot.rB.setTargetPosition(newRBTarget);

            // Turn On RUN_TO_POSITION
            //robot.setDrivetrainMode(lF.RunMode.RUN_TO_POSITION);
            robot.lF.setMode(DcMotor.RunMode.RUN_TO_POSITION);
            robot.rB.setMode(DcMotor.RunMode.RUN_TO_POSITION);

            // reset the timeout time and start motion.
            runtime.reset();
            robot.lF.setPower(Math.abs(speed));
            robot.rF.setPower(Math.abs(speed));
            robot.lB.setPower(Math.abs(speed));
            robot.rB.setPower(Math.abs(speed));

            // keep looping while we are still active, and there is time left, and both motors are running.
            // Note: We use (isBusy() && isBusy()) in the loop test, which means that when EITHER motor hits
            // its target position, the motion will stop.  This is "safer" in the event that the robot will
            // always end the motion as soon as possible.
            // However, if you require that BOTH motors have finished their moves before the robot continues
            // onto the next step, use (isBusy() || isBusy()) in the loop test.
            while (opModeIsActive() &&
                    (robot.lF.isBusy() && robot.rF.isBusy()
                            && robot.lB.isBusy() && robot.rB.isBusy())) {
            }


            // Stop all motion;
            robot.setMotorPowers(0);

            // Turn off RUN_TO_POSITION
            robot.setDrivetrainMode(DcMotor.RunMode.RUN_USING_ENCODER);

        */}/*
    }

    void initForward(){
        robot.lF.setDirection(DcMotorSimple.Direction.FORWARD);
        robot.rB.setDirection(DcMotorSimple.Direction.REVERSE);
        robot.rF.setDirection(DcMotorSimple.Direction.REVERSE);
        robot.lB.setDirection(DcMotorSimple.Direction.FORWARD);
    }

    void initBackward(){
        robot.lF.setDirection(DcMotorSimple.Direction.REVERSE);
        robot.rB.setDirection(DcMotorSimple.Direction.FORWARD);
        robot.rF.setDirection(DcMotorSimple.Direction.FORWARD);
        robot.lB.setDirection(DcMotorSimple.Direction.REVERSE);
    }

    void initRightStrafe(){
        robot.lF.setDirection(DcMotorSimple.Direction.REVERSE);
        robot.rB.setDirection(DcMotorSimple.Direction.FORWARD);
        robot.rF.setDirection(DcMotorSimple.Direction.REVERSE);
        robot.lB.setDirection(DcMotorSimple.Direction.FORWARD);
    }

    void initLeftStrafe(){
        robot.lF.setDirection(DcMotorSimple.Direction.FORWARD);
        robot.rB.setDirection(DcMotorSimple.Direction.REVERSE);
        robot.rF.setDirection(DcMotorSimple.Direction.FORWARD);
        robot.lB.setDirection(DcMotorSimple.Direction.REVERSE);
    }

    void initLeftTurn(){
        robot.lF.setDirection(DcMotorSimple.Direction.FORWARD);
        robot.rB.setDirection(DcMotorSimple.Direction.FORWARD);
        robot.rF.setDirection(DcMotorSimple.Direction.FORWARD);
        robot.lB.setDirection(DcMotorSimple.Direction.FORWARD);
    }

    void initRightTurn(){
        robot.lF.setDirection(DcMotorSimple.Direction.REVERSE);
        robot.rB.setDirection(DcMotorSimple.Direction.REVERSE);
        robot.rF.setDirection(DcMotorSimple.Direction.REVERSE);
        robot.lB.setDirection(DcMotorSimple.Direction.REVERSE);*/
    }
}

