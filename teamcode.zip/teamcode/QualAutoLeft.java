package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;

import com.qualcomm.robotcore.util.ElapsedTime;
import org.openftc.apriltag.AprilTagDetection;
import org.openftc.easyopencv.OpenCvCamera;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.hardware.DcMotor;

@com.qualcomm.robotcore.eventloop.opmode.Autonomous(name = "QualAutoLeft", group = "Autonomous")
public class QualAutoLeft extends LinearOpMode
{
    OpenCvCamera camera;
    Robot robot;

    static final double FEET_PER_METER = 3.28084;



    // Lens intrinsics
    // UNITS ARE PIXELS
    // NOTE: this calibration is for the C920 webcam at 800x448.
    // You will need to do your own calibration for other configurations!
    double fx = 78.272;
    double fy = 578.272;
    double cx = 402.145;
    double cy = 221.506;

    // UNITS ARE METERS
    double tagsize = 0.166;

    private ElapsedTime runtime = new ElapsedTime();

    static final double COUNTS_PER_MOTOR_REV = 1440 ;    // eg: TETRIX Motor Encoder
    static final double DRIVE_GEAR_REDUCTION = 2.0 ;     // This is < 1.0 if geared UP
    static final double WHEEL_DIAMETER_INCHES = 4.0 ;     // For figuring circumference
    static final double COUNTS_PER_INCH = (COUNTS_PER_MOTOR_REV * DRIVE_GEAR_REDUCTION)/(WHEEL_DIAMETER_INCHES * 3.1415);
    static final double DRIVE_SPEED = 0.6;
    static final double TURN_SPEED = 0.45;

        /*
        while (opModeIsActive()) {sleep(20);}
        UNCOMMENT IF NECESSARY
        */
    @Override
    public void runOpMode() throws InterruptedException {
        robot = new Robot(this);
        waitForStart();

        // CENTERSTAGE
        /*initLeftStrafe();
        robot.setMotorPowers(1);
        sleep(1150);
        /*
        initLeftStrafe();
        encoderDrive(DRIVE_SPEED, 9, 9, 9, 9);
        initBackward();
        encoderDrive(DRIVE_SPEED, 6, 6, 6, 6);
        initLeftStrafe();
        encoderDrive(DRIVE_SPEED, 11, 11, 11, 11);

         */

    }

/*    void initForward(){
        robot.lF.setDirection(DcMotorSimple.Direction.FORWARD);
        robot.rB.setDirection(DcMotorSimple.Direction.REVERSE);
        robot.rF.setDirection(DcMotorSimple.Direction.REVERSE);
        robot.lB.setDirection(DcMotorSimple.Direction.FORWARD);
    }

    void initBackward(){
        robot.lF.setDirection(DcMotorSimple.Direction.REVERSE);
        robot.rB.setDirection(DcMotorSimple.Direction.FORWARD);
        robot.rF.setDirection(DcMotorSimple.Direction.FORWARD);
        robot.lB.setDirection(DcMotorSimple.Direction.REVERSE);
    }

    void initRightStrafe(){
        robot.lF.setDirection(DcMotorSimple.Direction.FORWARD);
        robot.rB.setDirection(DcMotorSimple.Direction.REVERSE);
        robot.rF.setDirection(DcMotorSimple.Direction.FORWARD);
        robot.lB.setDirection(DcMotorSimple.Direction.REVERSE);
    }

    void initLeftStrafe(){
        robot.lF.setDirection(DcMotorSimple.Direction.FORWARD);
        robot.rB.setDirection(DcMotorSimple.Direction.REVERSE);
        robot.rF.setDirection(DcMotorSimple.Direction.FORWARD);
        robot.lB.setDirection(DcMotorSimple.Direction.REVERSE);
    }

//    void initUp(){
//        robot.aR.setDirection(DcMotorSimple.Direction.REVERSE);
//        robot.aL.setDirection(DcMotorSimple.Direction.FORWARD);
//    }
//
//    void initDown(){
//        robot.aR.setDirection(DcMotorSimple.Direction.FORWARD);
//        robot.aL.setDirection(DcMotorSimple.Direction.REVERSE);
//    }

//    public void encoderLiftDrive(double speed, double aL, double aR) {
//        int newALTarget;
//        int newARTarget;
//
//        // Ensure that the opmode is still active
//        if (opModeIsActive()) {
//
//            // Determine new target position, and pass to motor controller
//            newALTarget = robot.aL.getCurrentPosition() + (int)(aL * COUNTS_PER_INCH);
//            newARTarget = robot.aR.getCurrentPosition() + (int)(aR * COUNTS_PER_INCH);
//
//            robot.aL.setTargetPosition(newALTarget);
//            robot.aR.setTargetPosition(newARTarget);
//
//            // Turn On RUN_TO_POSITION
//            robot.setArmDrivetrainMode(DcMotor.RunMode.RUN_TO_POSITION);
//
//            // reset the timeout time and start motion.
//            runtime.reset();
//            robot.aL.setPower(Math.abs(speed));
//            robot.aR.setPower(Math.abs(speed));
//
//            // keep looping while we are still active, and there is time left, and both motors are running.
//            // Note: We use (isBusy() && isBusy()) in the loop test, which means that when EITHER motor hits
//            // its target position, the motion will stop.  This is "safer" in the event that the robot will
//            // always end the motion as soon as possible.
//            // However, if you require that BOTH motors have finished their moves before the robot continues
//            // onto the next step, use (isBusy() || isBusy()) in the loop test.
//            while (opModeIsActive() &&
//                    (robot.aL.isBusy() && robot.aR.isBusy())) {
//            }
//
//            // Stop all motion;
//            robot.setMotorPowers(0);
//
//            // Turn off RUN_TO_POSITION
//            robot.setArmDrivetrainMode(DcMotor.RunMode.RUN_USING_ENCODER);
//
//        }
//    }

    public void encoderDrive(double speed, double lF, double rF, double lB, double rB) {
        int newLFTarget;
        int newRFTarget;
        int newLBTarget;
        int newRBTarget;

        // Ensure that the opmode is still active
        if (opModeIsActive()) {

            // Determine new target position, and pass to motor controller
            newLFTarget = robot.lF.getCurrentPosition() + (int)(lF * COUNTS_PER_INCH
            );
            newRFTarget = robot.rF.getCurrentPosition() + (int)(rF * COUNTS_PER_INCH);
            newLBTarget = robot.lB.getCurrentPosition() + (int)(lB * COUNTS_PER_INCH);
            newRBTarget = robot.rB.getCurrentPosition() + (int)(rB * COUNTS_PER_INCH);

            robot.lF.setTargetPosition(newLFTarget);
            robot.rF.setTargetPosition(newRFTarget);
            robot.lB.setTargetPosition(newLBTarget);
            robot.rB.setTargetPosition(newRBTarget);

            // Turn On RUN_TO_POSITION
            robot.setDrivetrainMode(DcMotor.RunMode.RUN_TO_POSITION);

            // reset the timeout time and start motion.
            runtime.reset();
            robot.lF.setPower(Math.abs(speed));
            robot.rF.setPower(Math.abs(speed));
            robot.lB.setPower(Math.abs(speed));
            robot.rB.setPower(Math.abs(speed));

            // keep looping while we are still active, and there is time left, and both motors are running.
            // Note: We use (isBusy() && isBusy()) in the loop test, which means that when EITHER motor hits
            // its target position, the motion will stop.  This is "safer" in the event that the robot will
            // always end the motion as soon as possible.
            // However, if you require that BOTH motors have finished their moves before the robot continues
            // onto the next step, use (isBusy() || isBusy()) in the loop test.
            while (opModeIsActive() &&
                    (robot.lF.isBusy() && robot.rF.isBusy()
                            && robot.lB.isBusy() && robot.rB.isBusy())) {
            }


            // Stop all motion;
            robot.setMotorPowers(0);
            robot.lF.setPower(0);
            robot.rF.setPower(0);
            robot.lB.setPower(0);
            robot.rB.setPower(0);

            // Turn off RUN_TO_POSITION
            robot.setDrivetrainMode(DcMotor.RunMode.RUN_USING_ENCODER);

        }
    }





    void tagToTelemetry(AprilTagDetection detection)
    {
        telemetry.addLine(String.format("\nDetected tag ID=%d", detection.id));
        telemetry.addLine(String.format("Translation X: %.2f feet", detection.pose.x*FEET_PER_METER));
        telemetry.addLine(String.format("Translation Y: %.2f feet", detection.pose.y*FEET_PER_METER));
        telemetry.addLine(String.format("Translation Z: %.2f feet", detection.pose.z*FEET_PER_METER));
    }*/
}