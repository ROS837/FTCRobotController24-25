package org.firstinspires.ftc.teamcode;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.hardware.DcMotorSimple;

@com.qualcomm.robotcore.eventloop.opmode.TeleOp(name = "TeleOp", group = "teleOp")
public class TeleOp extends LinearOpMode {
    Robot robot;

    @Override
    public void runOpMode() throws InterruptedException {

        robot = new Robot(this);
        waitForStart();

        while(opModeIsActive()){
            if(gamepad1.a) {
                robot.myMotor.setPower(.25);
            } else {
                robot.myMotor.setPower(0);
            }

            if(gamepad1.left_stick_y > .15) {
                robot.grjnojg.setPower(1);
                robot.grjnojg.setDirection(DcMotorSimple.Direction.REVERSE);
            } else {
                robot.grjnojg.setPower(0);
            }

            // @EVERYYEAR MOVEMENT
            /*if(gamepad1.dpad_left) {
                robot.lF.setDirection(DcMotorSimple.Direction.FORWARD);
                robot.rB.setDirection(DcMotorSimple.Direction.FORWARD);
                robot.rF.setDirection(DcMotorSimple.Direction.FORWARD);
                robot.lB.setDirection(DcMotorSimple.Direction.FORWARD);
                robot.lF.setPower(1);
                robot.lB.setPower(1);
                robot.rF.setPower(1);
                robot.rB.setPower(1);
            } else {
                robot.lF.setPower(0);
                robot.lB.setPower(0);
                robot.rF.setPower(0);
                robot.rB.setPower(0);
            }

            if(gamepad1.dpad_right) {
                robot.lF.setDirection(DcMotorSimple.Direction.REVERSE);
                robot.rB.setDirection(DcMotorSimple.Direction.REVERSE);
                robot.rF.setDirection(DcMotorSimple.Direction.REVERSE);
                robot.lB.setDirection(DcMotorSimple.Direction.REVERSE);
                robot.lF.setPower(1);
                robot.lB.setPower(1);
                robot.rF.setPower(1);
                robot.rB.setPower(1);
            } else {
                robot.lF.setPower(0);
                robot.lB.setPower(0);
                robot.rF.setPower(0);
                robot.rB.setPower(0);
            }

            if(gamepad1.y) {
                robot.lF.setDirection(DcMotorSimple.Direction.FORWARD);
                robot.rB.setDirection(DcMotorSimple.Direction.REVERSE);
                robot.rF.setDirection(DcMotorSimple.Direction.REVERSE);
                robot.lB.setDirection(DcMotorSimple.Direction.FORWARD);
                robot.lF.setPower(1);
                robot.lB.setPower(0.95);
                robot.rF.setPower(0.95);
                robot.rB.setPower(0.95);
            } else {
                robot.lF.setPower(0);
                robot.lB.setPower(0);
                robot.rF.setPower(0);
                robot.rB.setPower(0);
            }

            if(gamepad1.a) {
                robot.lF.setDirection(DcMotorSimple.Direction.REVERSE);
                robot.rB.setDirection(DcMotorSimple.Direction.FORWARD);
                robot.rF.setDirection(DcMotorSimple.Direction.FORWARD);
                robot.lB.setDirection(DcMotorSimple.Direction.REVERSE);
                robot.lF.setPower(1);
                robot.lB.setPower(1);
                robot.rF.setPower(1);
                robot.rB.setPower(1);
            } else {
                robot.lF.setPower(0);
                robot.lB.setPower(0);
                robot.rF.setPower(0);
                robot.rB.setPower(0);
            }

            if(gamepad1.b) {
                robot.lF.setDirection(DcMotorSimple.Direction.REVERSE);
                robot.rB.setDirection(DcMotorSimple.Direction.FORWARD);
                robot.rF.setDirection(DcMotorSimple.Direction.REVERSE);
                robot.lB.setDirection(DcMotorSimple.Direction.FORWARD);
                robot.lF.setPower(1);
                robot.lB.setPower(1);
                robot.rF.setPower(1);
                robot.rB.setPower(1);
            } else {
                robot.lF.setPower(0);
                robot.lB.setPower(0);
                robot.rF.setPower(0);
                robot.rB.setPower(0);
            }

            if(gamepad1.x) {
                robot.lF.setDirection(DcMotorSimple.Direction.FORWARD);
                robot.rB.setDirection(DcMotorSimple.Direction.REVERSE);
                robot.rF.setDirection(DcMotorSimple.Direction.FORWARD);
                robot.lB.setDirection(DcMotorSimple.Direction.REVERSE);
                robot.lF.setPower(1);
                robot.lB.setPower(1);
                robot.rF.setPower(1);
                robot.rB.setPower(1);
            } else {
                robot.lF.setPower(0);
                robot.lB.setPower(0);
                robot.rF.setPower(0);
                robot.rB.setPower(0);
            }*/

            // CENTERSTAGE
            /*if(gamepad1.left_stick_y > .15){
                robot.hookDeployment.setDirection(DcMotorSimple.Direction.FORWARD);
                robot.hookDeployment.setPower(1);
            } else if(gamepad1.left_stick_y < -.15) {
                robot.hookDeployment.setDirection(DcMotorSimple.Direction.REVERSE);
                robot.hookDeployment.setPower(.5);
            } else {
                robot.hookDeployment.setPower(0);
            }

            if(gamepad1.right_stick_y > .15){
                robot.pixelMotor.setDirection(DcMotorSimple.Direction.FORWARD);
                robot.pixelMotor.setPower(.3);
            } else if(gamepad1.right_stick_y < -.15) {
                robot.pixelMotor.setDirection(DcMotorSimple.Direction.REVERSE);
                robot.pixelMotor.setPower(.3);
            } else {
                robot.pixelMotor.setPower(0);
            }

            if(gamepad1.left_trigger > .5) {
                robot.suspensionLeft.setDirection(DcMotorSimple.Direction.FORWARD);
                //robot.suspensionRight.setDirection(DcMotorSimple.Direction.REVERSE);
                robot.suspensionLeft.setPower(1);
                //robot.suspensionRight.setPower(.6);
            } else {
                robot.suspensionLeft.setPower(0);
                //robot.suspensionRight.setPower(0);
            }

            if(gamepad1.right_trigger > .5) {
                robot.suspensionLeft.setDirection(DcMotorSimple.Direction.REVERSE);
                //robot.suspensionRight.setDirection(DcMotorSimple.Direction.FORWARD);
                robot.suspensionLeft.setPower(.3);
                //robot.suspensionRight.setPower(.3);
            } else {
                robot.suspensionLeft.setPower(0);
                //robot.suspensionRight.setPower(0);
            }

            if(gamepad1.left_bumper && gamepad1.right_bumper) {
                robot.launch.setPosition(0.1);
            }

            if(gamepad1.dpad_down) {
                robot.pixelServo.setPosition(1);

            }*/

        }
    }
}