// Mark II
// Devashish Das 2023-2024
// Rohin Sharma 2023-2024

package org.firstinspires.ftc.teamcode;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.Servo;

public class Robot {
    LinearOpMode ln;

    DcMotor myMotor;
    DcMotor grjnojg;

    // @EVERYYEAR MOVEMENT
    /*DcMotor lF;
    String lFInit = "lF";

    DcMotor lB;
    String lBInit = "lB";

    DcMotor rF;
    String rFInit = "rF";

    DcMotor rB;
    String rBInit = "rB";*/

    // CENTERSTAGE
    /*DcMotor hookDeployment;
    String hookDeploymentInit = "hookDeployment";

    DcMotor suspensionLeft;
    String suspensionLeftInit = "suspensionLeft";

    DcMotor suspensionRight;
    String suspensionRightInit = "suspensionRight";

    DcMotor pixelMotor;
    String pixelMotorInit = "pixelMotor";

    Servo pixelServo;
    String pixelServoInit = "pixelServo";

    Servo launch;
    String launchInit = "launch";*/


    public Robot(LinearOpMode ln){
        myMotor = ln.hardwareMap.dcMotor.get("myMotor");
        grjnojg = ln.hardwareMap.dcMotor.get("lowerLeftWheel3");

        // @EVERYYEAR MOVEMENT
        /* lF = ln.hardwareMap.dcMotor.get(lFInit);
        lB = ln.hardwareMap.dcMotor.get(lBInit);
        rF = ln.hardwareMap.dcMotor.get(rFInit);
        rB = ln.hardwareMap.dcMotor.get(rBInit);*/

        // CENTERSTAGE
        /*hookDeployment = ln.hardwareMap.dcMotor.get(hookDeploymentInit);
        suspensionLeft = ln.hardwareMap.dcMotor.get(suspensionLeftInit);
        suspensionRight = ln.hardwareMap.dcMotor.get(suspensionRightInit);
        pixelMotor = ln.hardwareMap.dcMotor.get(pixelMotorInit);
        pixelServo = ln.hardwareMap.servo.get(pixelServoInit);
        launch = ln.hardwareMap.servo.get(launchInit);*/
    }

    // @EVERYYEAR DRIVETRAIN FUNCTIONS
    /*public void setDrivetrainMode(DcMotor.RunMode mode) {
        lF.setMode(mode);
        rF.setMode(mode);
        lB.setMode(mode);
        rB.setMode(mode);
    }

    public void setArmDrivetrainMode(DcMotor.RunMode mode) {
//        aL.setMode(mode);
//        aR.setMode(mode);
    }

    public void setMotorPowers(double LFPower, double RFPower, double LBPower, double RBPower) {
        lF.setPower(LFPower);
        rF.setPower(RFPower);
        lB.setPower(LBPower);
        rB.setPower(RBPower);
    }

    public void setMotorPowers(double allPower) {
        setMotorPowers(allPower, allPower, allPower, allPower);
    }

    public void setArmPowers(double LFPower, double RFPower) {
        lF.setPower(LFPower);
        rF.setPower(RFPower);
    }

    public void setArmPowers(double allPower) {
        setArmPowers(allPower, allPower);
    }*/

}